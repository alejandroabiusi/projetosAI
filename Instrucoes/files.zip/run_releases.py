"""
Runner para executar todos os scrapers de releases de RI.

Uso:
    python run_releases.py          # Executa todos
    python run_releases.py plano    # Apenas Plano&Plano
    python run_releases.py cury     # Apenas Cury
"""

import sys
from scrapers.planoeplano_ri import PlanoEPlanoRI


def main():
    filtro = sys.argv[1].lower() if len(sys.argv) > 1 else "todos"

    scrapers = {
        "plano": ("Plano&Plano", PlanoEPlanoRI),
        # "cury": ("Cury", CuryRI),  # Descomentar quando o scraper da Cury estiver pronto
    }

    if filtro != "todos" and filtro not in scrapers:
        print(f"Empresa '{filtro}' nao encontrada. Opcoes: {', '.join(scrapers.keys())}")
        sys.exit(1)

    empresas = scrapers if filtro == "todos" else {filtro: scrapers[filtro]}

    print("=" * 60)
    print("EXECUCAO DE SCRAPERS DE RELEASES")
    print("=" * 60)

    resultados = {}
    for chave, (nome, classe_scraper) in empresas.items():
        print(f"\n>>> Iniciando: {nome}")
        scraper = classe_scraper()
        resultado = scraper.executar()
        resultados[nome] = resultado

    print("\n" + "=" * 60)
    print("RESUMO GERAL")
    print("=" * 60)
    for nome, r in resultados.items():
        print(f"  {nome}: {r['novos']} novos | {r['existentes']} existentes | {r['erros']} erros")


if __name__ == "__main__":
    main()
