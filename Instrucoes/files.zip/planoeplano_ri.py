"""
Scraper de Releases de RI - Plano&Plano
========================================
Acessa a Central de Resultados no site de RI da Plano&Plano
(plataforma MZ Group), identifica os PDFs de releases trimestrais
e faz o download organizado.

A pagina carrega o conteudo via JavaScript (AJAX), entao o Selenium
e necessario para esperar o carregamento antes de extrair os links.

Uso:
    python scrapers/planoeplano_ri.py
"""

import os
import sys
import re
import time
from urllib.parse import urljoin

# Adiciona o diretorio raiz ao path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scrapers.base_scraper import BaseScraper
from config.settings import PLANOEPLANO, SELENIUM


class PlanoEPlanoRI(BaseScraper):
    """Scraper para releases trimestrais da Plano&Plano."""

    def __init__(self):
        super().__init__(
            nome_empresa=PLANOEPLANO["nome"],
            diretorio_downloads=PLANOEPLANO["downloads_releases"],
        )
        self.url_central = PLANOEPLANO["ri_url"]

    def _selecionar_ano(self, ano):
        """
        Na Central de Resultados da MZ Group, os documentos sao filtrados
        por ano via um seletor/dropdown. Este metodo tenta selecionar um ano
        especifico. Retorna True se conseguiu, False caso contrario.
        """
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.common.exceptions import TimeoutException

        try:
            # A MZ Group usa diferentes padroes de seletor de ano.
            # Tenta os mais comuns: select dropdown, botoes/abas, ou links.

            # Padrao 1: elemento <select> com opcoes de ano
            selects = self.driver.find_elements(By.TAG_NAME, "select")
            for select in selects:
                options = select.find_elements(By.TAG_NAME, "option")
                for option in options:
                    if str(ano) in option.text:
                        option.click()
                        self.logger.info(f"Ano {ano} selecionado via dropdown.")
                        self.aguardar(2)
                        return True

            # Padrao 2: links ou botoes com o texto do ano
            elementos_ano = self.driver.find_elements(
                By.XPATH,
                f"//*[contains(text(), '{ano}') and (self::a or self::button or self::li or self::span)]"
            )
            for elem in elementos_ano:
                if elem.is_displayed() and str(ano) == elem.text.strip():
                    elem.click()
                    self.logger.info(f"Ano {ano} selecionado via link/botao.")
                    self.aguardar(2)
                    return True

            # Padrao 3: abas com data-attributes
            abas = self.driver.find_elements(
                By.CSS_SELECTOR,
                f"[data-year='{ano}'], [data-value='{ano}'], [value='{ano}']"
            )
            for aba in abas:
                if aba.is_displayed():
                    aba.click()
                    self.logger.info(f"Ano {ano} selecionado via aba.")
                    self.aguardar(2)
                    return True

            self.logger.warning(f"Nao foi possivel selecionar o ano {ano}.")
            return False

        except Exception as e:
            self.logger.warning(f"Erro ao selecionar ano {ano}: {e}")
            return False

    def _extrair_links_pdf(self):
        """
        Extrai todos os links de PDF visiveis na pagina atual.
        Retorna lista de tuplas (nome_display, url_pdf).
        """
        from selenium.webdriver.common.by import By

        links_encontrados = []

        # Busca todos os links (<a>) que apontem para PDFs
        todos_links = self.driver.find_elements(By.TAG_NAME, "a")

        for link in todos_links:
            href = link.get_attribute("href") or ""
            texto = link.text.strip()

            # Filtra apenas links que parecem ser PDFs de resultados
            eh_pdf = (
                href.lower().endswith(".pdf")
                or "mzfilemanager" in href.lower()
                or "mziq.com" in href.lower()
            )

            if eh_pdf and href:
                # Tenta identificar se e um release de resultados
                texto_lower = texto.lower()
                eh_release = any(
                    termo in texto_lower
                    for termo in [
                        "release", "resultado", "earning", "press release",
                        "demonstra", "itr", "dfp",
                    ]
                )

                # Se o texto nao ajuda, pega qualquer PDF (na Central de Resultados,
                # a maioria dos PDFs sao relevantes)
                if eh_release or not texto:
                    links_encontrados.append((texto or "documento", href))

        # Remove duplicatas mantendo a ordem
        vistos = set()
        links_unicos = []
        for texto, url in links_encontrados:
            if url not in vistos:
                vistos.add(url)
                links_unicos.append((texto, url))

        return links_unicos

    def _gerar_nome_arquivo(self, texto, url, ano):
        """
        Gera um nome de arquivo descritivo para o PDF.
        Tenta extrair trimestre/ano do texto; se nao conseguir, usa a URL.
        """
        # Tenta extrair padrao como "1T25", "4T24", "3T2025" etc.
        padrao_tri = re.search(r"(\d)[Tt](\d{2,4})", texto)
        if padrao_tri:
            trimestre = padrao_tri.group(1)
            ano_tri = padrao_tri.group(2)
            if len(ano_tri) == 2:
                ano_tri = f"20{ano_tri}"
            return f"PlanoePlano_Release_{trimestre}T{ano_tri}.pdf"

        # Tenta extrair do texto descritivo
        texto_limpo = texto.lower()
        for t in ["1t", "2t", "3t", "4t"]:
            if t in texto_limpo:
                idx = texto_limpo.index(t)
                tri_num = texto_limpo[idx]
                return f"PlanoePlano_Release_{tri_num}T{ano}.pdf"

        # Se tem "anual" ou "dfp" ou "4t"
        if any(w in texto_limpo for w in ["anual", "dfp", "annual"]):
            return f"PlanoePlano_DFP_{ano}.pdf"

        # Ultimo recurso: usa hash parcial da URL
        url_hash = abs(hash(url)) % 100000
        return f"PlanoePlano_{ano}_{url_hash}.pdf"

    def executar(self, anos=None):
        """
        Executa o scraper para os anos especificados.
        Se nenhum ano for informado, tenta os ultimos 6 anos (2020-2026).
        """
        if anos is None:
            anos = list(range(2026, 2019, -1))  # 2026 ate 2020

        self.logger.info("=" * 60)
        self.logger.info("INICIANDO SCRAPER DE RELEASES - PLANO&PLANO")
        self.logger.info(f"URL: {self.url_central}")
        self.logger.info(f"Anos alvo: {anos}")
        self.logger.info("=" * 60)

        contadores = {"novos": 0, "existentes": 0, "erros": 0}

        try:
            self.iniciar_navegador()
            self.logger.info(f"Acessando {self.url_central}...")
            self.driver.get(self.url_central)

            # Espera inicial para a pagina carregar completamente
            self.aguardar(5)

            # Captura o HTML para debug caso necessario
            self.logger.info(f"Titulo da pagina: {self.driver.title}")

            # Para cada ano, seleciona o filtro e extrai os PDFs
            for ano in anos:
                self.logger.info(f"\n--- Processando ano {ano} ---")

                sucesso = self._selecionar_ano(ano)
                if not sucesso:
                    # Mesmo sem conseguir selecionar, tenta extrair o que estiver visivel
                    self.logger.info(
                        f"Tentando extrair links visiveis mesmo sem filtro de ano..."
                    )

                # Espera o conteudo carregar apos a selecao
                self.aguardar(3)

                links = self._extrair_links_pdf()
                self.logger.info(f"Links de PDF encontrados: {len(links)}")

                if not links:
                    self.logger.info(f"Nenhum PDF encontrado para {ano}.")
                    # Na primeira iteracao sem filtro, pega tudo que tiver
                    if ano == anos[0]:
                        self.logger.info(
                            "Tentando capturar todos os PDFs visiveis na pagina..."
                        )
                        links = self._extrair_links_pdf()
                    continue

                for texto, url_pdf in links:
                    nome_arquivo = self._gerar_nome_arquivo(texto, url_pdf, ano)

                    if self.arquivo_ja_existe(nome_arquivo):
                        self.logger.info(f"Ja existe: {nome_arquivo}")
                        contadores["existentes"] += 1
                        continue

                    sucesso_download = self.baixar_pdf(url_pdf, nome_arquivo)
                    if sucesso_download:
                        contadores["novos"] += 1
                    else:
                        contadores["erros"] += 1

                    self.aguardar()

                # Se ja conseguiu PDFs sem filtro de ano, nao precisa repetir
                if not sucesso and links:
                    self.logger.info(
                        "PDFs capturados sem filtro de ano. "
                        "Encerrando iteracao de anos para evitar duplicatas."
                    )
                    break

        except Exception as e:
            self.logger.error(f"Erro durante execucao: {e}", exc_info=True)
            contadores["erros"] += 1

        finally:
            self.fechar_navegador()

        self.gerar_relatorio(
            contadores["novos"], contadores["existentes"], contadores["erros"]
        )

        return contadores


# ============================================================
# EXECUCAO DIRETA
# ============================================================
if __name__ == "__main__":
    scraper = PlanoEPlanoRI()

    # Permite passar anos como argumentos: python planoeplano_ri.py 2025 2024
    if len(sys.argv) > 1:
        anos = [int(a) for a in sys.argv[1:]]
    else:
        anos = None  # Usa o padrao (2026-2020)

    resultado = scraper.executar(anos=anos)

    print(f"\nResumo: {resultado['novos']} novos, "
          f"{resultado['existentes']} ja existentes, "
          f"{resultado['erros']} erros.")
