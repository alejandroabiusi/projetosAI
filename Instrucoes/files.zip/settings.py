"""
Configuracoes centralizadas do projeto de scraping.
Todos os URLs, paths e parametros ficam aqui para facilitar manutencao.
"""

import os

# Diretorio raiz do projeto (resolve automaticamente independente de onde o script e chamado)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Diretorios de saida
DOWNLOADS_DIR = os.path.join(PROJECT_ROOT, "downloads")
LOGS_DIR = os.path.join(PROJECT_ROOT, "logs")
DATA_DIR = os.path.join(PROJECT_ROOT, "data")

# ============================================================
# PLANO&PLANO
# ============================================================
PLANOEPLANO = {
    "nome": "Plano&Plano",
    "ticker": "PLPL3",
    "ri_url": "https://ri.planoeplano.com.br/informacoes-financeiras/central-de-resultados/",
    "site_comercial": "https://www.planoeplano.com.br/",
    "downloads_releases": os.path.join(DOWNLOADS_DIR, "planoeplano", "releases"),
    "downloads_lancamentos": os.path.join(DOWNLOADS_DIR, "planoeplano", "lancamentos"),
}

# ============================================================
# CURY
# ============================================================
CURY = {
    "nome": "Cury",
    "ticker": "CURY3",
    "ri_url": "https://ri.cfrfrgi.com.br/",  # Verificar URL exato na primeira execucao
    "site_comercial": "https://www.cury.net/",
    "downloads_releases": os.path.join(DOWNLOADS_DIR, "cury", "releases"),
    "downloads_lancamentos": os.path.join(DOWNLOADS_DIR, "cury", "lancamentos"),
}

# ============================================================
# PARAMETROS DO SELENIUM
# ============================================================
SELENIUM = {
    "headless": True,          # True = roda sem abrir janela do navegador
    "timeout": 30,             # Segundos para esperar carregamento de pagina
    "wait_between_requests": 3,  # Segundos entre requisicoes (respeitar o site)
    "user_agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
}

# ============================================================
# PARAMETROS DO REQUESTS (para downloads de PDF)
# ============================================================
REQUESTS = {
    "timeout": 60,
    "headers": {
        "User-Agent": SELENIUM["user_agent"],
        "Accept": "application/pdf,*/*",
    },
}
